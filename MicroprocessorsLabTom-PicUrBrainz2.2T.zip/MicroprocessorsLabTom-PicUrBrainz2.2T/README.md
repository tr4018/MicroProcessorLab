  _____  _  _____  __     ______  _    _ _____    ____  _____            _ _   _ 
 |  __ \| |/ ____| \ \   / / __ \| |  | |  __ \  |  _ \|  __ \     /\   | | \ | |
 | |__) | | |       \ \_/ / |  | | |  | | |__) | | |_) | |__) |   /  \  | |  \| |
 |  ___/| | |        \   /| |  | | |  | |  _  /  |  _ <|  _  /   / /\ \ | | . ` |
 | |    |_| |____     | | | |__| | |__| | | \ \  | |_) | | \ \  / ____ \|_| |\  |
 |_|    (_)\_____|    |_|  \____/ \____/|_|  \_\ |____/|_|  \_\/_/    \_(_)_| \_|
                                                                                 
                                                                                 
>> An Arithmetic single-player game. (entirely self contained, simply run program once) 

>> To Start: Press the power button.
>> Select level: Press 1 = Multiplication, or 2 = Addition
>> Press ENTER when you have answered the question to submit your answer
>> You will receive a score, then decide to play again.
>> If you enter Standby, press the power button to re-enable the LCD

 